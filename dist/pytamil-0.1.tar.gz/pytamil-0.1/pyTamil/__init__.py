from .thirukural.thirukural import Thirukural


__all__ = ["Thirukural"]